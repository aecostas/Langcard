function send(msg) {
    document.title = "null";
    document.title = msg;
}